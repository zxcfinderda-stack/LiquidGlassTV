# Liquid Glass TV — starter project

Android TV launcher starter inspired by iOS 26 Liquid Glass. It uses translucent glass-style cards, a dark gradient background, a clock, installed-app tiles and DPAD focus scaling.

## Important
- This is an **initial source project**, not a prebuilt or tested APK.
- The look is inspired by glassmorphism; it does not copy Apple's system UI exactly.
- Device/firmware restrictions may prevent replacing the default HOME screen. The app also has a Leanback launcher entry so it can be opened from the TV apps list.
- The app lists launchable apps and attempts to open them. Some phone-only apps may not be TV-compatible.
- `QUERY_ALL_PACKAGES` is used so a sideloaded launcher can show installed apps.

## Build from iPhone using GitHub Actions (no computer)
1. Download and unzip this project on your iPhone Files app.
2. Create a new **public or private GitHub repository** in Safari.
3. Upload the *contents* of this folder so the repository root contains `settings.gradle`, `build.gradle`, `gradle.properties`, `app/`, and `.github/`.
   - GitHub's mobile web upload may be awkward for folders. If it cannot upload folders, use GitHub's web editor to create the files, or use a browser-based Git client that supports folder upload.
4. Open **Actions** in the repository. If GitHub asks, enable workflows.
5. Choose **Build Liquid Glass TV APK** and tap **Run workflow**. If the workflow is not listed, confirm `.github/workflows/build-apk.yml` is at the repository root (not nested).
6. When the run succeeds, open the run, scroll to **Artifacts**, and download `LiquidGlassTV-debug-apk`. Extract it to get `app-debug.apk`.

## Transfer APK to Android TV over Wi-Fi
1. On the TV box, install/open a trusted file-transfer app that can receive files over Wi-Fi (for example, a local HTTP file server or a file-transfer app you already trust). Keep iPhone and TV box on the same Wi-Fi.
2. Transfer `app-debug.apk` to the TV box.
3. In Android TV settings, allow installation from that file manager/browser when prompted. Install the APK.
4. Open **Liquid Glass TV** from the apps list. If Android asks which Home app to use, choose it temporarily first to test. Some boxes do not show this prompt or do not permit third-party HOME apps.

## Project layout
- `app/src/main/java/com/akwe/liquidglasstv/MainActivity.java` — launcher UI and app discovery
- `app/src/main/AndroidManifest.xml` — TV and HOME intent filters
- `.github/workflows/build-apk.yml` — cloud build workflow

## Troubleshooting
- If the build fails, open the failed workflow and copy the first red error block.
- If the launcher does not show all apps, your Android TV version may restrict package visibility or some apps may not expose TV launch activities.
- To return to the original launcher, open Android Settings > Apps > Default apps > Home app (names vary by firmware), or press Home and choose the original launcher.
