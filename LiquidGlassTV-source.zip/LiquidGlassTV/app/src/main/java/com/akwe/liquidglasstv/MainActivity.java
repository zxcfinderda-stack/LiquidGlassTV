package com.akwe.liquidglasstv;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class MainActivity extends Activity {
    private final Handler handler = new Handler();
    private TextView clockView;
    private LinearLayout appRow;
    private final List<AppEntry> apps = new ArrayList<>();
    private static class AppEntry {
        String label, packageName;
        android.graphics.drawable.Drawable icon;
        AppEntry(String l, String p, android.graphics.drawable.Drawable i) {
            label=l; packageName=p; icon=i;
        }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        buildUI();
        loadApps();
        updateClock();
    }

    private GradientDrawable rounded(int color, int stroke, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        if (stroke != 0) d.setStroke(2, stroke);
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        return t;
    }

    private void buildUI() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(48, 28, 48, 28);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{Color.rgb(20,25,48), Color.rgb(35,24,57), Color.rgb(7,16,31)}));
        setContentView(root);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = text("liquid glass", 28, Color.WHITE, true);
        top.addView(brand, new LinearLayout.LayoutParams(0, 62, 1));
        clockView = text("--:--", 23, Color.WHITE, true);
        clockView.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        top.addView(clockView);
        root.addView(top);

        TextView subtitle = text("YOUR TV. YOUR SPACE.", 12, 0xFFBFC9E8, true);
        subtitle.setLetterSpacing(0.20f);
        root.addView(subtitle, new LinearLayout.LayoutParams(-1, 28));

        TextView featured = text("  Добро пожаловать", 23, Color.WHITE, true);
        featured.setPadding(24, 0, 24, 0);
        featured.setBackground(rounded(0x553FFFFFF, 0x66FFFFFF, 28));
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, 82);
        fp.topMargin=22; fp.bottomMargin=24;
        root.addView(featured, fp);

        TextView appsTitle = text("Приложения", 20, Color.WHITE, true);
        root.addView(appsTitle, new LinearLayout.LayoutParams(-1, 34));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(false);
        appRow = new LinearLayout(this);
        appRow.setOrientation(LinearLayout.HORIZONTAL);
        appRow.setGravity(Gravity.TOP);
        scroll.addView(appRow, new ScrollView.LayoutParams(-1, -2));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, 0, 1);
        sp.topMargin=14;
        root.addView(scroll, sp);

        TextView hint = text("← → выбор     OK открыть     BACK выход", 12, 0xFFB8C3DE, false);
        hint.setGravity(Gravity.CENTER);
        root.addView(hint, new LinearLayout.LayoutParams(-1, 32));
    }

    private void loadApps() {
        PackageManager pm = getPackageManager();
        Set<String> seen = new HashSet<>();
        Intent leanback = new Intent(Intent.ACTION_MAIN);
        leanback.addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
        addResolved(pm, leanback, seen);
        Intent regular = new Intent(Intent.ACTION_MAIN);
        regular.addCategory(Intent.CATEGORY_LAUNCHER);
        addResolved(pm, regular, seen);

        Collections.sort(apps, (a,b) -> a.label.toLowerCase(Locale.ROOT)
            .compareTo(b.label.toLowerCase(Locale.ROOT)));

        for (AppEntry app : apps) {
            LinearLayout tile = new LinearLayout(this);
            tile.setOrientation(LinearLayout.VERTICAL);
            tile.setGravity(Gravity.CENTER);
            tile.setFocusable(true);
            tile.setFocusableInTouchMode(true);
            tile.setPadding(12, 16, 12, 12);
            tile.setBackground(rounded(0x44FFFFFF, 0x55FFFFFF, 26));
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(156, 154);
            tp.rightMargin=16; tp.bottomMargin=16;
            appRow.addView(tile, tp);

            TextView icon = text("", 36, Color.WHITE, true);
            icon.setGravity(Gravity.CENTER);
            icon.setCompoundDrawablesWithIntrinsicBounds(null, app.icon, null, null);
            icon.setCompoundDrawablePadding(6);
            tile.addView(icon, new LinearLayout.LayoutParams(74, 76));

            TextView label = text(app.label, 13, Color.WHITE, true);
            label.setGravity(Gravity.CENTER);
            label.setMaxLines(2);
            tile.addView(label, new LinearLayout.LayoutParams(-1, 48));

            tile.setOnClickListener(v -> launch(app.packageName));
            tile.setOnFocusChangeListener((v, focused) -> {
                v.animate().scaleX(focused ? 1.07f : 1f).scaleY(focused ? 1.07f : 1f)
                    .setDuration(160).start();
                v.setBackground(rounded(focused ? 0x88FFFFFF : 0x44FFFFFF,
                    focused ? 0xFFFFFFFF : 0x55FFFFFF, 26));
            });
        }
        if (apps.isEmpty()) {
            TextView empty = text("Не удалось найти приложения", 18, Color.WHITE, false);
            appRow.addView(empty);
        } else {
            appRow.setFocusable(false);
            if (appRow.getChildCount() > 0) appRow.getChildAt(0).requestFocus();
        }
    }

    private void addResolved(PackageManager pm, Intent intent, Set<String> seen) {
        try {
            List<android.content.pm.ResolveInfo> list = pm.queryIntentActivities(intent, 0);
            for (android.content.pm.ResolveInfo ri : list) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;
                CharSequence label = ri.loadLabel(pm);
                apps.add(new AppEntry(label == null ? pkg : label.toString(),
                    pkg, ri.loadIcon(pm)));
            }
        } catch (Exception ignored) {}
    }

    private void launch(String packageName) {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage(packageName);
            if (i == null) {
                i = new Intent(Intent.ACTION_MAIN);
                i.addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
                i.setPackage(packageName);
            }
            if (i != null) startActivity(i);
        } catch (Exception ignored) {}
    }

    private void updateClock() {
        if (clockView != null) {
            String value = new SimpleDateFormat("HH:mm  •  EEE, d MMM", Locale.getDefault()).format(new Date());
            clockView.setText(value);
        }
        handler.postDelayed(this::updateClock, 30_000);
    }

    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            // Keep the launcher on screen; Home button behavior is controlled by Android.
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
